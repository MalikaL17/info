# Модуль с функцией для расчета суммы двух чисел
def simple_func(x=3,y=4):
	return x+y

if __name__ == "__main__":
    print(simple_func())